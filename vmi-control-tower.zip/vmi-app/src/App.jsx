import { useState, useMemo, useRef, useCallback } from "react";

// ─── CONSTANTS ────────────────────────────────────────────────────────────────
const LINE_CAPACITY   = 3000;   // units per day on the single shared line
const TRANSIT_DAYS    = 2;      // days from pack-finish to receipt in country
const PLAN_START      = "2026-03-12";
const PLAN_DAYS       = 28;

const COUNTRIES = { DK:"Denmark",SE:"Sweden",NO:"Norway",FI:"Finland",DE:"Germany",NL:"Netherlands",BE:"Belgium",FR:"France",ES:"Spain",IT:"Italy" };
const SKU_FOR   = (c,t) => `${c}-${t.toUpperCase()}`;
const TREAT_COLOR = { Rapido:"#3b82f6", Insulat:"#a855f7", Mixed:"#10b981" };

// ─── STATIC DATA ─────────────────────────────────────────────────────────────
const BASE_INV = [
  {sku:"DK-RAPIDO", country:"DK",treatment:"Rapido", onHand:420, avgDemand:35, target:630, warning:350,critical:210},
  {sku:"DK-INSULAT",country:"DK",treatment:"Insulat",onHand:600, avgDemand:25, target:500, warning:300,critical:175},
  {sku:"DK-MIXED",  country:"DK",treatment:"Mixed",  onHand:360, avgDemand:18, target:288, warning:162,critical:90},
  {sku:"SE-RAPIDO", country:"SE",treatment:"Rapido", onHand:720, avgDemand:40, target:720, warning:400,critical:240},
  {sku:"SE-INSULAT",country:"SE",treatment:"Insulat",onHand:360, avgDemand:30, target:600, warning:360,critical:210},
  {sku:"SE-MIXED",  country:"SE",treatment:"Mixed",  onHand:280, avgDemand:20, target:320, warning:180,critical:100},
  {sku:"NO-RAPIDO", country:"NO",treatment:"Rapido", onHand:480, avgDemand:30, target:540, warning:300,critical:180},
  {sku:"NO-INSULAT",country:"NO",treatment:"Insulat",onHand:484, avgDemand:22, target:440, warning:264,critical:154},
  {sku:"NO-MIXED",  country:"NO",treatment:"Mixed",  onHand:192, avgDemand:16, target:256, warning:144,critical:80},
  {sku:"FI-RAPIDO", country:"FI",treatment:"Rapido", onHand:336, avgDemand:28, target:504, warning:280,critical:168},
  {sku:"FI-INSULAT",country:"FI",treatment:"Insulat",onHand:360, avgDemand:20, target:400, warning:240,critical:140},
  {sku:"FI-MIXED",  country:"FI",treatment:"Mixed",  onHand:300, avgDemand:15, target:240, warning:135,critical:75},
  {sku:"DE-RAPIDO", country:"DE",treatment:"Rapido", onHand:840, avgDemand:120,target:2160,warning:1200,critical:720},
  {sku:"DE-INSULAT",country:"DE",treatment:"Insulat",onHand:1530,avgDemand:85, target:1700,warning:1020,critical:595},
  {sku:"DE-MIXED",  country:"DE",treatment:"Mixed",  onHand:1200,avgDemand:60, target:960, warning:540,critical:300},
  {sku:"NL-RAPIDO", country:"NL",treatment:"Rapido", onHand:1375,avgDemand:55, target:990, warning:550,critical:330},
  {sku:"NL-INSULAT",country:"NL",treatment:"Insulat",onHand:640, avgDemand:40, target:800, warning:480,critical:280},
  {sku:"NL-MIXED",  country:"NL",treatment:"Mixed",  onHand:450, avgDemand:25, target:400, warning:225,critical:125},
  {sku:"BE-RAPIDO", country:"BE",treatment:"Rapido", onHand:900, avgDemand:45, target:810, warning:450,critical:270},
  {sku:"BE-INSULAT",country:"BE",treatment:"Insulat",onHand:490, avgDemand:35, target:700, warning:420,critical:245},
  {sku:"BE-MIXED",  country:"BE",treatment:"Mixed",  onHand:120, avgDemand:20, target:320, warning:180,critical:100},
  {sku:"FR-RAPIDO", country:"FR",treatment:"Rapido", onHand:1980,avgDemand:110,target:1980,warning:1100,critical:660},
  {sku:"FR-INSULAT",country:"FR",treatment:"Insulat",onHand:960, avgDemand:80, target:1600,warning:960,critical:560},
  {sku:"FR-MIXED",  country:"FR",treatment:"Mixed",  onHand:605, avgDemand:55, target:880, warning:495,critical:275},
  {sku:"ES-RAPIDO", country:"ES",treatment:"Rapido", onHand:1530,avgDemand:85, target:1530,warning:850,critical:510},
  {sku:"ES-INSULAT",country:"ES",treatment:"Insulat",onHand:720, avgDemand:60, target:1200,warning:720,critical:420},
  {sku:"ES-MIXED",  country:"ES",treatment:"Mixed",  onHand:160, avgDemand:40, target:640, warning:360,critical:200},
  {sku:"IT-RAPIDO", country:"IT",treatment:"Rapido", onHand:1440,avgDemand:90, target:1620,warning:900,critical:540},
  {sku:"IT-INSULAT",country:"IT",treatment:"Insulat",onHand:585, avgDemand:65, target:1300,warning:780,critical:455},
  {sku:"IT-MIXED",  country:"IT",treatment:"Mixed",  onHand:540, avgDemand:45, target:720, warning:405,critical:225},
];

// Each order: packDate = production start date; production takes ceil(qty/LINE_CAPACITY) days
const INITIAL_ORDERS = [
  {id:"OL-1003",po:"PO-1003",country:"DK",treatment:"Insulat",sku:"DK-INSULAT",packDate:"2026-03-16",qty:300, status:"In Transit",expedite:"Yes",planner:"Factory Planner",notes:"Strong stock position.",userCreated:false},
  {id:"OL-1031",po:"PO-1031",country:"NL",treatment:"Rapido", sku:"NL-RAPIDO", packDate:"2026-03-16",qty:616, status:"Released",  expedite:"Yes",planner:"Factory Planner",notes:"Early replenishment.",userCreated:false},
  {id:"OL-1001",po:"PO-1001",country:"DK",treatment:"Rapido", sku:"DK-RAPIDO", packDate:"2026-03-18",qty:336, status:"In Transit",expedite:"Yes",planner:"Factory Planner",notes:"",userCreated:false},
  {id:"OL-1023",po:"PO-1023",country:"FI",treatment:"Mixed",  sku:"FI-MIXED",  packDate:"2026-03-18",qty:135, status:"In Transit",expedite:"Yes",planner:"Factory Planner",notes:"",userCreated:false},
  {id:"OL-1027",po:"PO-1027",country:"DE",treatment:"Insulat",sku:"DE-INSULAT",packDate:"2026-03-18",qty:850, status:"In Transit",expedite:"Yes",planner:"Factory Planner",notes:"",userCreated:false},
  {id:"OL-1037",po:"PO-1037",country:"BE",treatment:"Rapido", sku:"BE-RAPIDO", packDate:"2026-03-19",qty:432, status:"Planned",   expedite:"Yes",planner:"Factory Planner",notes:"",userCreated:false},
  {id:"OL-1029",po:"PO-1029",country:"DE",treatment:"Mixed",  sku:"DE-MIXED",  packDate:"2026-03-19",qty:540, status:"Planned",   expedite:"Yes",planner:"Factory Planner",notes:"",userCreated:false},
  {id:"OL-1059",po:"PO-1059",country:"IT",treatment:"Mixed",  sku:"IT-MIXED",  packDate:"2026-03-19",qty:405, status:"Planned",   expedite:"Yes",planner:"Factory Planner",notes:"",userCreated:false},
  {id:"OL-1033",po:"PO-1033",country:"NL",treatment:"Insulat",sku:"NL-INSULAT",packDate:"2026-03-19",qty:400, status:"Planned",   expedite:"Yes",planner:"Factory Planner",notes:"",userCreated:false},
  {id:"OL-1007",po:"PO-1007",country:"SE",treatment:"Rapido", sku:"SE-RAPIDO", packDate:"2026-03-19",qty:384, status:"Planned",   expedite:"Yes",planner:"Factory Planner",notes:"",userCreated:false},
  {id:"OL-1009",po:"PO-1009",country:"SE",treatment:"Insulat",sku:"SE-INSULAT",packDate:"2026-03-20",qty:300, status:"Released",  expedite:"Yes",planner:"Factory Planner",notes:"",userCreated:false},
  {id:"OL-1057",po:"PO-1057",country:"IT",treatment:"Insulat",sku:"IT-INSULAT",packDate:"2026-03-20",qty:650, status:"Released",  expedite:"Yes",planner:"Factory Planner",notes:"Borderline case.",userCreated:false},
  {id:"OL-1053",po:"PO-1053",country:"ES",treatment:"Mixed",  sku:"ES-MIXED",  packDate:"2026-03-21",qty:324, status:"Delayed",   expedite:"Yes",planner:"Factory Planner",notes:"Packaging issue.",userCreated:false},
  {id:"OL-1049",po:"PO-1049",country:"ES",treatment:"Rapido", sku:"ES-RAPIDO", packDate:"2026-03-21",qty:816, status:"In Transit",expedite:"Yes",planner:"Factory Planner",notes:"",userCreated:false},
  {id:"OL-1025",po:"PO-1025",country:"DE",treatment:"Rapido", sku:"DE-RAPIDO", packDate:"2026-03-22",qty:1248,status:"Delayed",   expedite:"Yes",planner:"Factory Planner",notes:"Large DE order delayed.",userCreated:false},
  {id:"OL-1051",po:"PO-1051",country:"ES",treatment:"Insulat",sku:"ES-INSULAT",packDate:"2026-03-22",qty:600, status:"Released",  expedite:"Yes",planner:"Factory Planner",notes:"",userCreated:false},
  {id:"OL-1041",po:"PO-1041",country:"BE",treatment:"Mixed",  sku:"BE-MIXED",  packDate:"2026-03-23",qty:144, status:"On Hold",   expedite:"No", planner:"Factory Planner",notes:"Quality hold.",userCreated:false},
  {id:"OL-1058",po:"PO-1058",country:"IT",treatment:"Insulat",sku:"IT-INSULAT",packDate:"2026-03-25",qty:650, status:"Planned",   expedite:"Yes",planner:"Factory Planner",notes:"",userCreated:false},
];

// ─── HELPERS ──────────────────────────────────────────────────────────────────
const d2n = (s) => { const d=new Date(s+"T12:00:00Z"); return Math.floor(d.getTime()/86400000); };
const n2d = (n) => { const d=new Date(n*86400000); return d.toISOString().split("T")[0]; };
const START_N = d2n(PLAN_START);
const dayOffset = (dateStr) => d2n(dateStr) - START_N;
const offsetToDate = (off) => n2d(START_N + off);
const prodDays = (qty) => Math.max(1, Math.ceil(qty / LINE_CAPACITY));
const packEnd  = (o) => dayOffset(o.packDate) + prodDays(o.qty) - 1; // inclusive last prod day
const receiptOffset = (o) => packEnd(o) + TRANSIT_DAYS + 1;
const receiptDate = (o) => offsetToDate(receiptOffset(o));

function calcStatus(oh, base) {
  if (oh <= base.critical) return "Critical";
  if (oh <= base.warning)  return "Warning";
  if (oh <  base.target)   return "Below Target";
  return "Healthy";
}

function addDays(ds, n) {
  const d = new Date(ds+"T12:00:00Z"); d.setUTCDate(d.getUTCDate()+n);
  return d.toISOString().split("T")[0];
}

function nextIds(orders) {
  const nums = orders.map(o=>parseInt(o.id.replace("OL-",""))).filter(n=>!isNaN(n));
  const n = Math.max(0,...nums)+1;
  return {id:`OL-${n}`,po:`PO-${n}`};
}

function fmtDate(ds) {
  const d = new Date(ds+"T12:00:00Z");
  return d.toLocaleDateString("en-GB",{day:"2-digit",month:"short"});
}

// Compute load per day (units) from orders
function computeLoad(orders) {
  const load = {};
  orders.forEach(o => {
    const start = dayOffset(o.packDate);
    const days  = prodDays(o.qty);
    const daily = o.qty / days;
    for (let i=0; i<days; i++) {
      const k = start+i;
      load[k] = (load[k]||0) + daily;
    }
  });
  return load;
}

// Build 28-day stock projection for one SKU given orders
function buildProjection(base, orders, days=PLAN_DAYS) {
  const relevant = orders.filter(o=>o.sku===base.sku && o.status!=="On Hold");
  const rows = [];
  let stock = base.onHand;
  for (let i=0; i<days; i++) {
    const receipts = relevant
      .filter(o => receiptOffset(o) === i)
      .reduce((s,o)=>s+o.qty,0);
    const opening = stock;
    stock = Math.max(0, stock + receipts - base.avgDemand);
    rows.push({ day:i, date:offsetToDate(i), opening, receipts, demand:base.avgDemand, closing:stock });
  }
  return rows;
}

// ─── SHARED STYLE HELPERS ─────────────────────────────────────────────────────
const SC = {
  Healthy:       {bg:"#0d2b1a",text:"#22c55e",dot:"#22c55e"},
  "Below Target":{bg:"#1c1a08",text:"#eab308",dot:"#eab308"},
  Warning:       {bg:"#2b1a0d",text:"#f97316",dot:"#f97316"},
  Critical:      {bg:"#2b0d0d",text:"#ef4444",dot:"#ef4444"},
};
const OC = {"In Transit":"#3b82f6",Released:"#22c55e",Planned:"#a78bfa",Delayed:"#f97316","On Hold":"#ef4444"};

function StatusBadge({status,small}) {
  const c=SC[status]||{bg:"#1e293b",text:"#94a3b8",dot:"#94a3b8"};
  return <span style={{background:c.bg,color:c.text,border:`1px solid ${c.dot}33`,borderRadius:4,padding:small?"1px 7px":"3px 10px",fontSize:small?9:11,fontWeight:700,letterSpacing:"0.05em",display:"inline-flex",alignItems:"center",gap:4,whiteSpace:"nowrap"}}>
    <span style={{width:5,height:5,borderRadius:"50%",background:c.dot,flexShrink:0}}/>
    {status.toUpperCase()}
  </span>;
}
function OrderBadge({status}) {
  const color=OC[status]||"#94a3b8";
  return <span style={{background:`${color}1a`,color,border:`1px solid ${color}44`,borderRadius:4,padding:"2px 8px",fontSize:10,fontWeight:700,letterSpacing:"0.06em",whiteSpace:"nowrap"}}>{status.toUpperCase()}</span>;
}
function StockBar({value,target,warning,critical,width=90}) {
  const sc=target*1.4; const fill=Math.min(value/sc,1);
  let color="#22c55e";
  if(value<=critical)color="#ef4444"; else if(value<=warning)color="#f97316"; else if(value<target)color="#eab308";
  return <div style={{position:"relative",width,height:5,background:"#1e293b",borderRadius:3,overflow:"visible"}}>
    <div style={{position:"absolute",left:0,top:0,height:"100%",width:`${fill*100}%`,background:color,borderRadius:3,transition:"width 0.4s"}}/>
    {[[warning/sc,"#f97316"],[target/sc,"#22c55e55"]].map(([p,c],i)=>(
      <div key={i} style={{position:"absolute",top:-2,left:`${p*100}%`,width:1,height:9,background:c}}/>
    ))}
  </div>;
}

// ─── PROJECTION MINI CHART (SVG sparkline) ────────────────────────────────────
function ProjectionChart({rows, base, width=340, height=70}) {
  if(!rows||rows.length===0) return null;
  const vals = rows.map(r=>r.closing);
  const mn=0, mx=Math.max(...vals,base.target)*1.1;
  const range=mx-mn||1;
  const W=width,H=height;
  const px=(i)=>(i/(rows.length-1))*W;
  const py=(v)=>H-((v-mn)/range)*H;
  const polyPts = vals.map((v,i)=>`${px(i)},${py(v)}`).join(" ");
  const tLine = py(base.target);
  const wLine = py(base.warning);
  const cLine = py(base.critical);
  return (
    <svg width={W} height={H} style={{overflow:"visible",display:"block"}}>
      {/* zones */}
      <rect x={0} y={cLine} width={W} height={Math.max(0,H-cLine)} fill="#ef444410"/>
      <rect x={0} y={wLine} width={W} height={Math.max(0,cLine-wLine)} fill="#f9731610"/>
      {/* target line */}
      <line x1={0} y1={tLine} x2={W} y2={tLine} stroke="#22c55e" strokeWidth={1} strokeDasharray="3,3" opacity={0.6}/>
      <line x1={0} y1={wLine} x2={W} y2={wLine} stroke="#f97316" strokeWidth={1} strokeDasharray="2,3" opacity={0.5}/>
      <line x1={0} y1={cLine} x2={W} y2={cLine} stroke="#ef4444" strokeWidth={1} strokeDasharray="2,3" opacity={0.4}/>
      {/* receipt spikes */}
      {rows.map((r,i)=> r.receipts>0 && (
        <line key={i} x1={px(i)} y1={H} x2={px(i)} y2={py(r.closing)} stroke="#22c55e" strokeWidth={2} opacity={0.35}/>
      ))}
      {/* closing line */}
      <polyline points={polyPts} fill="none" stroke="#38bdf8" strokeWidth={2}/>
      {/* dots where closing goes below warning */}
      {rows.map((r,i)=> r.closing<=base.warning && (
        <circle key={i} cx={px(i)} cy={py(r.closing)} r={2.5} fill="#ef4444"/>
      ))}
      <circle cx={px(rows.length-1)} cy={py(vals[vals.length-1])} r={3} fill="#38bdf8"/>
    </svg>
  );
}

// ─── GANTT PLANNING BOARD ─────────────────────────────────────────────────────
function GanttBoard({orders, onMoveOrder, onSelectOrder, selectedId, inventory}) {
  const dragRef = useRef(null);
  const boardRef = useRef(null);
  const DAY_W = 36; // px per day
  const ROW_H = 34;
  const LABEL_W = 110;

  const visibleOrders = useMemo(()=>
    orders.filter(o=>o.status!=="On Hold")
          .sort((a,b)=>dayOffset(a.packDate)-dayOffset(b.packDate))
  ,[orders]);

  const load = useMemo(()=>computeLoad(visibleOrders),[visibleOrders]);

  // days header
  const days = Array.from({length:PLAN_DAYS},(_,i)=>i);

  function onMouseDown(e, orderId) {
    e.preventDefault();
    const rect = boardRef.current.getBoundingClientRect();
    const startX = e.clientX;
    const origOffset = dayOffset(orders.find(o=>o.id===orderId).packDate);

    dragRef.current = { orderId, startX, origOffset };

    function onMove(ev) {
      const dx = ev.clientX - startX;
      const dayDelta = Math.round(dx / DAY_W);
      const newOffset = Math.max(0, origOffset + dayDelta);
      dragRef.current.newOffset = newOffset;
      // visual only: handled by state update below
    }
    function onUp(ev) {
      if(dragRef.current?.newOffset !== undefined) {
        onMoveOrder(orderId, offsetToDate(dragRef.current.newOffset));
      }
      dragRef.current = null;
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    }
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  }

  // capacity utilisation color
  function loadColor(units) {
    const pct = units / LINE_CAPACITY;
    if(pct > 1)   return "#ef4444";
    if(pct > 0.8) return "#f97316";
    if(pct > 0.5) return "#eab308";
    return "#22c55e";
  }

  return (
    <div style={{background:"#080e1c",border:"1px solid #1a2740",borderRadius:10,overflow:"hidden"}}>
      {/* Legend */}
      <div style={{padding:"10px 16px",borderBottom:"1px solid #1a2740",display:"flex",gap:20,alignItems:"center",flexWrap:"wrap"}}>
        <span style={{fontSize:11,fontWeight:800,color:"#e2e8f0",letterSpacing:"0.04em"}}>PRODUCTION LINE · Shared · {LINE_CAPACITY.toLocaleString()} units/day</span>
        <div style={{display:"flex",gap:12,marginLeft:"auto"}}>
          {Object.entries(TREAT_COLOR).map(([t,c])=>(
            <span key={t} style={{display:"flex",alignItems:"center",gap:5,fontSize:10,color:"#64748b",fontFamily:"sans-serif"}}>
              <span style={{width:10,height:10,borderRadius:2,background:c,display:"inline-block"}}/>
              {t}
            </span>
          ))}
          <span style={{display:"flex",alignItems:"center",gap:5,fontSize:10,color:"#64748b",fontFamily:"sans-serif"}}>
            <span style={{width:10,height:3,background:"#ef4444",display:"inline-block"}}/>Overloaded
          </span>
        </div>
      </div>

      <div style={{overflowX:"auto"}} ref={boardRef}>
        <div style={{minWidth: LABEL_W + PLAN_DAYS*DAY_W + 40}}>

          {/* Date header */}
          <div style={{display:"flex",position:"sticky",top:0,zIndex:5,background:"#060c18",borderBottom:"1px solid #1a2740"}}>
            <div style={{width:LABEL_W,flexShrink:0,padding:"6px 10px",fontSize:9,color:"#334155",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.1em",fontFamily:"sans-serif"}}>ORDER</div>
            {days.map(i=>{
              const ds = offsetToDate(i);
              const d  = new Date(ds+"T12:00:00Z");
              const isWeekend = d.getUTCDay()===0||d.getUTCDay()===6;
              const isToday = i===0;
              return (
                <div key={i} style={{width:DAY_W,flexShrink:0,textAlign:"center",fontSize:9,color:isToday?"#38bdf8":isWeekend?"#334155":"#4a6080",fontWeight:isToday?800:400,borderLeft:"1px solid #0f1a2e",padding:"4px 0",background:isWeekend?"#060c18":"transparent",fontFamily:"sans-serif",position:"relative"}}>
                  {i%2===0 && <>{d.getUTCDate()}<br/><span style={{fontSize:8,opacity:0.6}}>{d.toLocaleDateString("en",{month:"short"})}</span></>}
                  {isToday && <div style={{position:"absolute",bottom:0,left:"50%",transform:"translateX(-50%)",width:1,height:4,background:"#38bdf8"}}/>}
                </div>
              );
            })}
          </div>

          {/* Load bar */}
          <div style={{display:"flex",borderBottom:"1px solid #1a2740",background:"#06090f"}}>
            <div style={{width:LABEL_W,flexShrink:0,padding:"4px 10px",fontSize:9,color:"#4a6080",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.08em",display:"flex",alignItems:"center",fontFamily:"sans-serif"}}>LOAD</div>
            {days.map(i=>{
              const units = load[i]||0;
              const pct   = Math.min(units/LINE_CAPACITY,1.05);
              const color = loadColor(units);
              return (
                <div key={i} title={`${Math.round(units).toLocaleString()} / ${LINE_CAPACITY.toLocaleString()} units (${Math.round(pct*100)}%)`}
                  style={{width:DAY_W,flexShrink:0,borderLeft:"1px solid #0a0f1a",padding:"3px 2px",display:"flex",alignItems:"flex-end",height:24}}>
                  <div style={{width:"100%",height:`${Math.min(pct,1)*100}%`,minHeight:units>0?2:0,background:color,borderRadius:"2px 2px 0 0",opacity:0.8,transition:"height 0.3s"}}/>
                </div>
              );
            })}
          </div>

          {/* Capacity pct labels every 7 days */}
          <div style={{display:"flex",borderBottom:"1px solid #1a2740",background:"#06090f"}}>
            <div style={{width:LABEL_W,flexShrink:0,padding:"2px 10px",fontSize:8,color:"#334155",fontFamily:"sans-serif"}}>utilisation</div>
            {days.map(i=>{
              const units=load[i]||0;
              const pct=Math.round(units/LINE_CAPACITY*100);
              return (
                <div key={i} style={{width:DAY_W,flexShrink:0,borderLeft:"1px solid #0a0f1a",fontSize:8,textAlign:"center",color:loadColor(units),padding:"2px 0",fontFamily:"'Courier New',monospace"}}>
                  {i%2===0&&pct>0?pct+"%":""}
                </div>
              );
            })}
          </div>

          {/* Order rows */}
          {visibleOrders.map((o,ri)=>{
            const start = dayOffset(o.packDate);
            const dur   = prodDays(o.qty);
            const end   = start + dur - 1;
            const rcpt  = receiptOffset(o);
            const base  = BASE_INV.find(b=>b.sku===o.sku);
            const color = TREAT_COLOR[o.treatment]||"#64748b";
            const isSelected = selectedId===o.id;
            const isDelayed  = o.status==="Delayed";
            const overload   = Array.from({length:dur},(_,i)=>(load[start+i]||0)>LINE_CAPACITY).some(Boolean);

            return (
              <div key={o.id} style={{display:"flex",alignItems:"center",borderBottom:"1px solid #0c1520",background:isSelected?"#0d1e36":ri%2===0?"#080e1c":"#060c18",cursor:"pointer",transition:"background 0.15s"}}
                onClick={()=>onSelectOrder(o.id===selectedId?null:o.id)}>
                {/* Label */}
                <div style={{width:LABEL_W,flexShrink:0,padding:"4px 10px",display:"flex",flexDirection:"column",gap:1}}>
                  <span style={{fontSize:10,fontWeight:700,color:o.userCreated?"#4ade80":color,fontFamily:"'Courier New',monospace",letterSpacing:"-0.02em"}}>{o.id}</span>
                  <span style={{fontSize:9,color:"#4a6080",fontFamily:"sans-serif"}}>{o.sku}</span>
                </div>

                {/* Timeline cells */}
                <div style={{position:"relative",flex:1,height:ROW_H,display:"flex"}}>
                  {days.map(i=>(
                    <div key={i} style={{width:DAY_W,flexShrink:0,borderLeft:"1px solid #0a0f1a",height:"100%",background:i===0?"#0a0f2a":"transparent"}}/>
                  ))}

                  {/* Production bar */}
                  {start < PLAN_DAYS && (
                    <div
                      onMouseDown={(e)=>{ if(o.status!=="In Transit") onMouseDown(e,o.id); }}
                      title={`${o.id}: ${o.qty.toLocaleString()} units · Prod: ${fmtDate(o.packDate)}→${fmtDate(offsetToDate(end))} · Receipt: ${fmtDate(receiptDate(o))}`}
                      style={{
                        position:"absolute",
                        left: start*DAY_W,
                        top: 5, height: 20,
                        width: Math.min(dur, PLAN_DAYS-start)*DAY_W - 2,
                        background: isDelayed ? "#7f1d1d" : `${color}cc`,
                        border: `1.5px solid ${overload?"#ef4444":isSelected?color+"ff":color+"88"}`,
                        borderRadius:4,
                        cursor: o.status==="In Transit" ? "default" : "grab",
                        display:"flex",alignItems:"center",paddingLeft:5,
                        boxShadow: isSelected?`0 0 0 1px ${color}, 0 2px 8px ${color}44`:"none",
                        overflow:"hidden",
                        userSelect:"none",
                        zIndex:2,
                      }}>
                      <span style={{fontSize:9,color:"#fff",fontWeight:700,fontFamily:"'Courier New',monospace",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>
                        {o.qty.toLocaleString()}u {isDelayed?"⚠":""}
                      </span>
                    </div>
                  )}

                  {/* Transit arrow */}
                  {end < PLAN_DAYS && rcpt < PLAN_DAYS && (
                    <div style={{
                      position:"absolute",
                      left:(end+1)*DAY_W,
                      top:13,
                      width:(rcpt-end-1)*DAY_W,
                      height:3,
                      background:`${color}44`,
                      zIndex:1,
                    }}/>
                  )}

                  {/* Receipt marker */}
                  {rcpt < PLAN_DAYS && rcpt >= 0 && (
                    <div title={`Receipt: ${fmtDate(receiptDate(o))}`} style={{
                      position:"absolute",
                      left:rcpt*DAY_W+DAY_W/2-4,
                      top:8,
                      width:8,height:14,
                      background:`${color}`,
                      borderRadius:2,
                      zIndex:3,
                      opacity:0.9,
                    }}/>
                  )}
                </div>
              </div>
            );
          })}

          {/* Today line overlay — just a colored col header highlight already done */}
        </div>
      </div>

      <div style={{padding:"8px 16px",borderTop:"1px solid #1a2740",fontSize:10,color:"#334155",fontFamily:"sans-serif",display:"flex",gap:16}}>
        <span>📦 <b style={{color:"#4a6080"}}>Bar</b> = production window · <b style={{color:"#4a6080"}}>Thin line</b> = transit · <b style={{color:"#4a6080"}}>Marker</b> = receipt in country</span>
        <span style={{marginLeft:"auto"}}>Drag bars to reschedule (non-In-Transit orders)</span>
      </div>
    </div>
  );
}

// ─── STOCK PROJECTION VIEW ────────────────────────────────────────────────────
function ProjectionView({orders, baseInv}) {
  const [country,   setCountry]   = useState("DK");
  const [treatment, setTreatment] = useState("Rapido");

  const sku  = SKU_FOR(country,treatment);
  const base = baseInv.find(b=>b.sku===sku);
  const rows = useMemo(()=> base ? buildProjection(base, orders) : [], [base,orders]);

  const td = {padding:"6px 10px",fontSize:11,borderBottom:"1px solid #0b1221",textAlign:"right",fontFamily:"'Courier New',monospace",whiteSpace:"nowrap"};

  return (
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      {/* Controls */}
      <div style={{display:"flex",gap:10,alignItems:"center",flexWrap:"wrap"}}>
        <select value={country} onChange={e=>setCountry(e.target.value)}
          style={{background:"#0b1221",border:"1px solid #1a2740",color:"#e2e8f0",borderRadius:6,padding:"7px 10px",fontSize:13,fontWeight:700,outline:"none"}}>
          {Object.entries(COUNTRIES).map(([c,n])=><option key={c} value={c}>{c} — {n}</option>)}
        </select>
        {["Rapido","Insulat","Mixed"].map(t=>(
          <button key={t} onClick={()=>setTreatment(t)}
            style={{background:treatment===t?`${TREAT_COLOR[t]}22`:"#0b1221",border:`1px solid ${treatment===t?TREAT_COLOR[t]:"#1a2740"}`,color:treatment===t?TREAT_COLOR[t]:"#64748b",borderRadius:6,padding:"6px 16px",fontSize:12,fontWeight:700,cursor:"pointer"}}>
            {t}
          </button>
        ))}
        <span style={{fontSize:10,color:"#4a6080",marginLeft:"auto",fontFamily:"sans-serif"}}>SKU: <b style={{color:"#38bdf8",fontFamily:"'Courier New',monospace"}}>{sku}</b></span>
      </div>

      {base && (
        <>
          {/* KPI strip */}
          <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
            {[
              {label:"On Hand",     value:base.onHand,        color:"#38bdf8"},
              {label:"Avg Daily",   value:base.avgDemand+"u", color:"#a78bfa"},
              {label:"Target",      value:base.target,        color:"#22c55e"},
              {label:"Warning",     value:base.warning,       color:"#f97316"},
              {label:"Critical",    value:base.critical,      color:"#ef4444"},
              {label:"Days Cover",  value:Math.round(base.onHand/base.avgDemand)+"d", color:base.onHand/base.avgDemand<10?"#ef4444":"#94a3b8"},
            ].map(k=>(
              <div key={k.label} style={{background:"#0b1221",border:"1px solid #1a2740",borderRadius:6,padding:"8px 14px",flex:"1 1 90px",textAlign:"center"}}>
                <div style={{fontSize:9,color:"#4a6080",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.08em",marginBottom:3,fontFamily:"sans-serif"}}>{k.label}</div>
                <div style={{fontSize:18,fontWeight:800,color:k.color,fontFamily:"'Courier New',monospace"}}>{typeof k.value==="number"?k.value.toLocaleString():k.value}</div>
              </div>
            ))}
          </div>

          {/* Chart */}
          <div style={{background:"#0b1221",border:"1px solid #1a2740",borderRadius:8,padding:"16px 20px"}}>
            <div style={{fontSize:10,color:"#4a6080",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:12,fontFamily:"sans-serif"}}>28-Day Stock Projection — updates live with plan changes</div>
            <div style={{overflowX:"auto"}}>
              <ProjectionChart rows={rows} base={base} width={Math.max(600,PLAN_DAYS*22)} height={90}/>
              <div style={{display:"flex",gap:14,marginTop:8,fontSize:10,color:"#4a6080",fontFamily:"sans-serif"}}>
                <span>— <span style={{color:"#38bdf8"}}>Closing stock</span></span>
                <span>-- <span style={{color:"#22c55e"}}>Target</span></span>
                <span>-- <span style={{color:"#f97316"}}>Warning</span></span>
                <span>-- <span style={{color:"#ef4444"}}>Critical</span></span>
                <span>| <span style={{color:"#22c55e",opacity:0.5}}>Receipt</span></span>
              </div>
            </div>
          </div>

          {/* Table */}
          <div style={{overflowX:"auto",borderRadius:8,border:"1px solid #1a2740"}}>
            <table style={{width:"100%",borderCollapse:"collapse"}}>
              <thead>
                <tr>{["Date","Opening","Receipts","Demand","Closing","vs Target","vs Warning","Status"].map(h=>(
                  <th key={h} style={{textAlign:h==="Date"?"left":"right",fontSize:9,color:"#4a6080",fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",padding:"7px 10px",background:"#060c18",whiteSpace:"nowrap"}}>{h}</th>
                ))}</tr>
              </thead>
              <tbody>
                {rows.map((row,ri)=>{
                  const st = calcStatus(row.closing,base);
                  const vt = row.closing-base.target;
                  const vw = row.closing-base.warning;
                  return (
                    <tr key={ri} style={{background:ri%2===0?"#0b1221":"#080e1c"}}>
                      <td style={{...td,textAlign:"left",color:"#64748b",fontSize:10}}>{fmtDate(row.date)}</td>
                      <td style={td}>{row.opening.toLocaleString()}</td>
                      <td style={{...td,color:row.receipts>0?"#22c55e":"#1e2d45",fontWeight:row.receipts>0?700:400}}>{row.receipts>0?"+"+row.receipts.toLocaleString():"—"}</td>
                      <td style={{...td,color:"#f97316"}}>{row.demand.toLocaleString()}</td>
                      <td style={{...td,fontWeight:700,color:SC[st]?.text||"#e2e8f0"}}>{row.closing.toLocaleString()}</td>
                      <td style={{...td,color:vt>=0?"#22c55e":"#ef4444"}}>{vt>=0?"+":""}{vt.toLocaleString()}</td>
                      <td style={{...td,color:vw>=0?"#22c55e":"#ef4444"}}>{vw>=0?"+":""}{vw.toLocaleString()}</td>
                      <td style={{...td,textAlign:"right"}}><StatusBadge status={st} small/></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

// ─── LEAD TIME CALCULATOR ─────────────────────────────────────────────────────
function LeadTimeView({orders}) {
  const [qty,      setQty]      = useState("500");
  const [startDay, setStartDay] = useState(PLAN_START);

  const load = useMemo(()=>computeLoad(orders.filter(o=>o.status!=="On Hold")),[orders]);

  // Simulate scheduling: find the earliest startDay where we can fit 'qty' units
  // considering existing load. We fill day by day until all qty produced.
  const calcSchedule = useCallback((startDateStr, targetQty) => {
    const startOff = dayOffset(startDateStr);
    let remaining = targetQty;
    const days = [];
    let off = startOff;
    while(remaining > 0 && off < startOff+60) {
      const existing = load[off]||0;
      const avail = Math.max(0, LINE_CAPACITY - existing);
      const produced = Math.min(avail, remaining);
      if(produced > 0) {
        days.push({off, date:offsetToDate(off), existing, avail, produced});
        remaining -= produced;
      } else {
        days.push({off, date:offsetToDate(off), existing, avail:0, produced:0, blocked:true});
      }
      off++;
    }
    return { days, finishDate: offsetToDate(off-1), receiptDate: offsetToDate(off-1+TRANSIT_DAYS+1), daysNeeded: off-startOff };
  },[load]);

  const qtyNum = parseInt(qty)||0;
  const schedule = qtyNum > 0 ? calcSchedule(startDay, qtyNum) : null;
  const simpleProdDays = prodDays(qtyNum);
  const simpleFinish   = addDays(startDay, simpleProdDays-1);
  const simpleReceipt  = addDays(simpleFinish, TRANSIT_DAYS+1);

  return (
    <div style={{display:"flex",flexDirection:"column",gap:18}}>
      {/* Info banner */}
      <div style={{background:"#0b1221",border:"1px solid #1a2740",borderRadius:8,padding:"14px 18px"}}>
        <div style={{fontSize:11,fontWeight:800,color:"#e2e8f0",marginBottom:6}}>Production Line Lead-Time Calculator</div>
        <div style={{fontSize:12,color:"#64748b",lineHeight:1.7,fontFamily:"sans-serif"}}>
          The shared line runs at <b style={{color:"#38bdf8"}}>{LINE_CAPACITY.toLocaleString()} units/day</b>.
          Lead time = <b style={{color:"#a78bfa"}}>⌈qty ÷ capacity⌉ days</b> production + <b style={{color:"#22c55e"}}>{TRANSIT_DAYS} days</b> transit to country.
          The "With Existing Load" view accounts for already-scheduled orders competing for capacity.
        </div>
      </div>

      {/* Input */}
      <div style={{display:"flex",gap:14,alignItems:"flex-end",flexWrap:"wrap"}}>
        <div style={{display:"flex",flexDirection:"column",gap:5}}>
          <label style={{fontSize:10,color:"#4a6080",fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",fontFamily:"sans-serif"}}>Quantity (units)</label>
          <input type="number" min={1} value={qty} onChange={e=>setQty(e.target.value)}
            style={{background:"#0b1221",border:"1px solid #1a2740",color:"#e2e8f0",borderRadius:6,padding:"9px 14px",fontSize:16,fontWeight:800,outline:"none",width:180,fontFamily:"'Courier New',monospace"}}/>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:5}}>
          <label style={{fontSize:10,color:"#4a6080",fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",fontFamily:"sans-serif"}}>Production Start Date</label>
          <input type="date" value={startDay} onChange={e=>setStartDay(e.target.value)}
            style={{background:"#0b1221",border:"1px solid #1a2740",color:"#e2e8f0",borderRadius:6,padding:"9px 14px",fontSize:13,outline:"none"}}/>
        </div>
      </div>

      {qtyNum > 0 && (
        <>
          {/* Results cards */}
          <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
            {/* Simple (no contention) */}
            <div style={{flex:"1 1 220px",background:"#05120a",border:"1px solid #22c55e33",borderRadius:10,padding:"18px 20px"}}>
              <div style={{fontSize:10,color:"#22c55e",fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:12,fontFamily:"sans-serif"}}>Without Existing Load</div>
              {[
                {label:"Production days",  value:simpleProdDays+"d",   color:"#38bdf8"},
                {label:"Production finish", value:fmtDate(simpleFinish), color:"#e2e8f0"},
                {label:"Transit days",      value:TRANSIT_DAYS+"d",     color:"#a78bfa"},
                {label:"Receipt in country",value:fmtDate(simpleReceipt),color:"#22c55e"},
                {label:"Total lead time",   value:(simpleProdDays+TRANSIT_DAYS+1)+"d", color:"#38bdf8"},
                {label:"Daily rate",        value:LINE_CAPACITY.toLocaleString()+" u/d",color:"#4a6080"},
              ].map(r=>(
                <div key={r.label} style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                  <span style={{fontSize:11,color:"#4a6080",fontFamily:"sans-serif"}}>{r.label}</span>
                  <span style={{fontSize:12,fontWeight:800,color:r.color,fontFamily:"'Courier New',monospace"}}>{r.value}</span>
                </div>
              ))}
            </div>

            {/* With contention */}
            {schedule && (
              <div style={{flex:"1 1 220px",background:"#0b0d1a",border:"1px solid #3b82f633",borderRadius:10,padding:"18px 20px"}}>
                <div style={{fontSize:10,color:"#3b82f6",fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:12,fontFamily:"sans-serif"}}>With Existing Scheduled Load</div>
                {[
                  {label:"Production days needed", value:schedule.daysNeeded+"d",       color:"#38bdf8"},
                  {label:"Production finish",       value:fmtDate(schedule.finishDate),  color:"#e2e8f0"},
                  {label:"Receipt in country",      value:fmtDate(schedule.receiptDate), color:schedule.daysNeeded>simpleProdDays?"#f97316":"#22c55e"},
                  {label:"Delay vs unconstrained",  value:schedule.daysNeeded>simpleProdDays?`+${schedule.daysNeeded-simpleProdDays}d`:"None", color:schedule.daysNeeded>simpleProdDays?"#f97316":"#22c55e"},
                  {label:"Blocked days",            value:schedule.days.filter(d=>d.blocked).length+"d", color:"#ef4444"},
                ].map(r=>(
                  <div key={r.label} style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                    <span style={{fontSize:11,color:"#4a6080",fontFamily:"sans-serif"}}>{r.label}</span>
                    <span style={{fontSize:12,fontWeight:800,color:r.color,fontFamily:"'Courier New',monospace"}}>{r.value}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Rate table */}
            <div style={{flex:"2 1 300px",background:"#0b1221",border:"1px solid #1a2740",borderRadius:10,padding:"18px 20px"}}>
              <div style={{fontSize:10,color:"#4a6080",fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:12,fontFamily:"sans-serif"}}>Lead Time by Batch Size</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(130px,1fr))",gap:8}}>
                {[100,250,500,750,1000,1500,2000,3000,4500,6000].map(q=>{
                  const pd = prodDays(q);
                  const total = pd + TRANSIT_DAYS + 1;
                  return (
                    <div key={q} style={{background:q===qtyNum?"#0d1e36":"#080e1c",border:`1px solid ${q===qtyNum?"#3b82f6":"#1a2740"}`,borderRadius:6,padding:"8px 12px"}}>
                      <div style={{fontSize:9,color:"#4a6080",fontFamily:"sans-serif"}}>{q.toLocaleString()} units</div>
                      <div style={{fontSize:14,fontWeight:800,color:q===qtyNum?"#38bdf8":"#e2e8f0",fontFamily:"'Courier New',monospace"}}>{total}d</div>
                      <div style={{fontSize:9,color:"#334155",fontFamily:"sans-serif"}}>{pd}d prod + {TRANSIT_DAYS+1}d transit</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Day-by-day capacity breakdown */}
          {schedule && schedule.days.length > 0 && (
            <div style={{background:"#080e1c",border:"1px solid #1a2740",borderRadius:8,padding:16}}>
              <div style={{fontSize:10,color:"#4a6080",fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:12,fontFamily:"sans-serif"}}>Day-by-Day Schedule (with existing load)</div>
              <div style={{overflowX:"auto"}}>
                <table style={{width:"100%",borderCollapse:"collapse",minWidth:500}}>
                  <thead>
                    <tr>{["Day","Date","Existing Load","Available","Produced","Remaining","Line %"].map(h=>(
                      <th key={h} style={{textAlign:"left",fontSize:9,color:"#334155",fontWeight:700,letterSpacing:"0.08em",textTransform:"uppercase",padding:"6px 10px",background:"#060c18",fontFamily:"sans-serif"}}>{h}</th>
                    ))}</tr>
                  </thead>
                  <tbody>
                    {(()=>{
                      let rem = qtyNum;
                      return schedule.days.map((row,i)=>{
                        rem = Math.max(0, rem-row.produced);
                        const linePct = Math.round((row.existing+row.produced)/LINE_CAPACITY*100);
                        return (
                          <tr key={i} style={{background:row.blocked?"#1a0505":i%2===0?"#0b1221":"#080e1c"}}>
                            <td style={{padding:"5px 10px",fontSize:10,color:"#4a6080",fontFamily:"sans-serif"}}>{row.off - dayOffset(startDay)+1}</td>
                            <td style={{padding:"5px 10px",fontSize:11,color:"#94a3b8",fontFamily:"sans-serif"}}>{fmtDate(row.date)}</td>
                            <td style={{padding:"5px 10px",fontSize:11,color:"#64748b",fontFamily:"'Courier New',monospace",textAlign:"right"}}>{Math.round(row.existing).toLocaleString()}</td>
                            <td style={{padding:"5px 10px",fontSize:11,color:row.avail>0?"#22c55e":"#ef4444",fontFamily:"'Courier New',monospace",textAlign:"right",fontWeight:700}}>{row.avail>0?row.avail.toLocaleString():"FULL"}</td>
                            <td style={{padding:"5px 10px",fontSize:11,color:"#38bdf8",fontFamily:"'Courier New',monospace",textAlign:"right",fontWeight:700}}>{row.produced>0?"+"+Math.round(row.produced).toLocaleString():"—"}</td>
                            <td style={{padding:"5px 10px",fontSize:11,color:rem===0?"#22c55e":"#e2e8f0",fontFamily:"'Courier New',monospace",textAlign:"right"}}>{rem.toLocaleString()}</td>
                            <td style={{padding:"5px 10px",textAlign:"right"}}>
                              <span style={{fontSize:10,fontWeight:700,color:linePct>100?"#ef4444":linePct>80?"#f97316":"#22c55e",fontFamily:"'Courier New',monospace"}}>{linePct}%</span>
                            </td>
                          </tr>
                        );
                      });
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function Dashboard({inventory, orders, onCreateOrder}) {
  const critical = inventory.filter(i=>i.status==="Critical").length;
  const warning  = inventory.filter(i=>i.status==="Warning").length;
  const below    = inventory.filter(i=>i.status==="Below Target").length;
  const healthy  = inventory.filter(i=>i.status==="Healthy").length;
  const delayed  = orders.filter(o=>o.status==="Delayed").length;
  const newOrd   = orders.filter(o=>o.userCreated).length;
  const urgent   = inventory.filter(i=>i.status==="Critical"||i.status==="Warning");

  return (
    <div style={{display:"flex",flexDirection:"column",gap:20}}>
      <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
        {[
          {label:"Critical",value:critical,color:"#ef4444",bg:"#1a0505"},
          {label:"Warning", value:warning, color:"#f97316",bg:"#1a0e05"},
          {label:"Below Target",value:below,color:"#eab308",bg:"#161205"},
          {label:"Healthy", value:healthy, color:"#22c55e",bg:"#051a0d"},
          {label:"Delayed", value:delayed, color:"#f97316",bg:"#1a0e05"},
          {label:"Planner Orders",value:newOrd,color:"#38bdf8",bg:"#05121a"},
        ].map(k=>(
          <div key={k.label} style={{background:k.bg,border:`1px solid ${k.color}2a`,borderRadius:8,padding:"12px 18px",flex:"1 1 110px"}}>
            <div style={{fontSize:9,color:"#4a6080",fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:5,fontFamily:"sans-serif"}}>{k.label}</div>
            <div style={{fontSize:28,fontWeight:800,color:k.color,fontFamily:"'Courier New',monospace"}}>{k.value}</div>
          </div>
        ))}
      </div>

      {urgent.length>0 && (
        <div style={{background:"#0b1221",border:"1px solid #ef444430",borderRadius:10,overflow:"hidden"}}>
          <div style={{background:"#120608",padding:"10px 16px",display:"flex",justifyContent:"space-between",alignItems:"center",borderBottom:"1px solid #1a2030"}}>
            <span style={{fontSize:11,color:"#ef4444",fontWeight:700,letterSpacing:"0.1em"}}>⚠ {urgent.length} URGENT SKUs NEED REPLENISHMENT</span>
            <button onClick={()=>onCreateOrder(null)} style={{background:"linear-gradient(135deg,#dc2626,#7c3aed)",border:"none",color:"#fff",padding:"5px 14px",borderRadius:5,fontSize:11,fontWeight:700,cursor:"pointer"}}>+ Create Order</button>
          </div>
          <div style={{padding:14,display:"flex",flexWrap:"wrap",gap:10}}>
            {urgent.map(i=>{
              const suggested=Math.max(0,i.target-i.onHand);
              return (
                <div key={i.sku} style={{background:"#080e1c",border:`1px solid ${SC[i.status]?.dot||"#ef4444"}30`,borderRadius:8,padding:"12px 14px",flex:"1 1 200px",minWidth:200}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:5}}>
                    <span style={{fontSize:13,fontWeight:800,color:"#e2e8f0",fontFamily:"'Courier New',monospace"}}>{i.sku}</span>
                    <StatusBadge status={i.status} small/>
                  </div>
                  <div style={{fontSize:10,color:"#4a6080",marginBottom:7,fontFamily:"sans-serif"}}>{COUNTRIES[i.country]} · {i.treatment}</div>
                  <StockBar value={i.onHand} target={i.target} warning={i.warning} critical={i.critical} width="100%"/>
                  <div style={{fontSize:10,color:"#64748b",marginTop:5,display:"flex",justifyContent:"space-between",fontFamily:"'Courier New',monospace"}}>
                    <span>On hand: <b style={{color:"#e2e8f0"}}>{i.onHand}</b></span>
                    <span>Target: <b style={{color:"#22c55e"}}>{i.target}</b></span>
                  </div>
                  <button onClick={()=>onCreateOrder({country:i.country,treatment:i.treatment,qty:String(suggested),notes:`Fix ${i.status} alert on ${i.sku}. Suggested: ${suggested.toLocaleString()} units.`})}
                    style={{marginTop:9,width:"100%",background:"#0d1e36",border:"1px solid #2563eb44",color:"#60a5fa",padding:"6px 0",borderRadius:5,fontSize:11,fontWeight:700,cursor:"pointer"}}>
                    + Order {suggested.toLocaleString()} units
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))",gap:10}}>
        {Object.entries(COUNTRIES).map(([code,name])=>{
          const inv=inventory.filter(i=>i.country===code);
          const alerts=inv.filter(i=>i.status==="Critical"||i.status==="Warning").length;
          const total=inv.reduce((s,i)=>s+i.onHand,0);
          return (
            <div key={code} style={{background:"#0b1221",border:`1px solid ${alerts>0?"#f9731630":"#1a2740"}`,borderRadius:8,padding:"12px 16px"}}>
              <div style={{display:"flex",justifyContent:"space-between"}}>
                <div>
                  <div style={{fontSize:19,fontWeight:800,color:"#e2e8f0",fontFamily:"'Courier New',monospace"}}>{code}</div>
                  <div style={{fontSize:10,color:"#4a6080",fontFamily:"sans-serif"}}>{name}</div>
                </div>
                {alerts>0&&<span style={{background:"#ef444415",color:"#ef4444",border:"1px solid #ef444430",borderRadius:4,fontSize:9,fontWeight:700,padding:"2px 7px"}}>{alerts}⚠</span>}
              </div>
              <div style={{marginTop:9,fontSize:10,color:"#64748b",fontFamily:"sans-serif"}}>On hand: <span style={{color:"#e2e8f0",fontWeight:700,fontFamily:"'Courier New',monospace"}}>{total.toLocaleString()}</span></div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── CREATE ORDER MODAL ───────────────────────────────────────────────────────
function CreateOrderModal({onClose, onSubmit, orders, inventory, prefill}) {
  const [country,  setCountry]  = useState(prefill?.country||"");
  const [treat,    setTreat]    = useState(prefill?.treatment||"");
  const [qty,      setQty]      = useState(prefill?.qty||"");
  const [packDate, setPackDate] = useState(PLAN_START);
  const [status,   setStatus]   = useState("Planned");
  const [expedite, setExpedite] = useState("Yes");
  const [planner,  setPlanner]  = useState("Factory Planner");
  const [notes,    setNotes]    = useState(prefill?.notes||"");
  const [errors,   setErrors]   = useState({});
  const [done,     setDone]     = useState(false);

  const sku = country&&treat ? SKU_FOR(country,treat) : null;
  const base = sku ? inventory.find(i=>i.sku===sku) : null;
  const qn = parseInt(qty)||0;
  const pd = qn>0 ? prodDays(qn) : 0;
  const finishDate = pd>0 ? addDays(packDate,pd-1) : null;
  const rcptDate   = finishDate  ? addDays(finishDate, TRANSIT_DAYS+1) : null;
  const projOH  = base&&qn>0 ? base.onHand+qn : null;
  const afterSt = projOH!==null ? calcStatus(projOH,base) : null;
  const toTarget= base ? Math.max(0,base.target-base.onHand) : 0;

  function validate() {
    const e={};
    if(!country) e.country="Required";
    if(!treat)   e.treat="Required";
    if(!qty||qn<=0) e.qty="Positive qty required";
    setErrors(e);
    return !Object.keys(e).length;
  }
  function submit() {
    if(!validate()) return;
    const ids=nextIds(orders);
    onSubmit({...ids,country,treatment:treat,sku:SKU_FOR(country,treat),packDate,qty:qn,status,expedite,planner,notes,included:1,userCreated:true});
    setDone(true);
    setTimeout(onClose,600);
  }

  const fld={background:"#080e1c",border:"1px solid #1e2d45",color:"#e2e8f0",borderRadius:6,padding:"8px 12px",fontSize:13,outline:"none",width:"100%",boxSizing:"border-box"};
  const lbl={fontSize:10,color:"#4a6080",fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",display:"block",marginBottom:4,fontFamily:"sans-serif"};

  return (
    <div onClick={e=>{if(e.target===e.currentTarget)onClose();}}
      style={{position:"fixed",inset:0,background:"rgba(2,6,18,0.85)",zIndex:200,display:"flex",alignItems:"center",justifyContent:"center",padding:16,backdropFilter:"blur(6px)"}}>
      <div style={{background:"#0b1221",border:"1px solid #1a2740",borderRadius:12,width:"100%",maxWidth:700,maxHeight:"92vh",overflowY:"auto",boxShadow:"0 32px 96px rgba(0,0,0,0.7)"}}>
        <div style={{padding:"16px 22px",borderBottom:"1px solid #1a2740",display:"flex",justifyContent:"space-between",alignItems:"center",background:"#080e1c",borderRadius:"12px 12px 0 0"}}>
          <div>
            <div style={{fontSize:14,fontWeight:800,color:"#e2e8f0",fontFamily:"'Courier New',monospace"}}>+ Create Production Order</div>
            {pd>0&&<div style={{fontSize:11,color:"#4a6080",marginTop:2,fontFamily:"sans-serif"}}>Production: {pd}d · Transit: {TRANSIT_DAYS+1}d · Total: {pd+TRANSIT_DAYS+1}d lead time</div>}
          </div>
          <button onClick={onClose} style={{background:"#1e293b",border:"none",color:"#64748b",cursor:"pointer",width:28,height:28,borderRadius:5,fontSize:16,display:"flex",alignItems:"center",justifyContent:"center"}}>×</button>
        </div>

        <div style={{display:"flex",gap:0,flexWrap:"wrap"}}>
          <div style={{flex:"1 1 320px",padding:22,display:"flex",flexDirection:"column",gap:16}}>
            {prefill?.notes&&<div style={{background:"#181408",border:"1px solid #eab30840",borderRadius:8,padding:"10px 14px",fontSize:11,color:"#94a3b8",lineHeight:1.6,fontFamily:"sans-serif"}}><span style={{color:"#eab308",fontWeight:700}}>⚡ SUGGESTION: </span>{prefill.notes}</div>}

            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
              <div>
                <label style={lbl}>Country</label>
                <select value={country} onChange={e=>{setCountry(e.target.value);setErrors(p=>({...p,country:null}));}} style={{...fld,borderColor:errors.country?"#ef4444":"#1e2d45"}}>
                  <option value="">— Select —</option>
                  {Object.entries(COUNTRIES).map(([k,v])=><option key={k} value={k}>{k} — {v}</option>)}
                </select>
                {errors.country&&<div style={{fontSize:10,color:"#ef4444",marginTop:2}}>{errors.country}</div>}
              </div>
              <div>
                <label style={lbl}>Treatment</label>
                <select value={treat} onChange={e=>{setTreat(e.target.value);setErrors(p=>({...p,treat:null}));}} style={{...fld,borderColor:errors.treat?"#ef4444":"#1e2d45"}}>
                  <option value="">— Select —</option>
                  <option value="Rapido">Rapido</option><option value="Insulat">Insulat</option><option value="Mixed">Mixed</option>
                </select>
              </div>
            </div>

            {sku&&base&&(
              <div style={{background:"#080e1c",border:"1px solid #1a2740",borderRadius:6,padding:"9px 12px",display:"flex",gap:14,flexWrap:"wrap"}}>
                <div><div style={lbl}>SKU</div><div style={{fontSize:12,fontWeight:800,color:"#38bdf8",fontFamily:"'Courier New',monospace"}}>{sku}</div></div>
                <div><div style={lbl}>On Hand</div><div style={{fontSize:12,fontWeight:700,color:"#e2e8f0",fontFamily:"'Courier New',monospace"}}>{base.onHand.toLocaleString()}</div></div>
                <div><div style={lbl}>Target</div><div style={{fontSize:12,fontWeight:700,color:"#22c55e",fontFamily:"'Courier New',monospace"}}>{base.target.toLocaleString()}</div></div>
                <div><div style={lbl}>Status</div><StatusBadge status={calcStatus(base.onHand,base)} small/></div>
              </div>
            )}

            <div>
              <label style={lbl}>Quantity</label>
              <div style={{display:"flex",gap:8}}>
                <input type="number" min={1} value={qty} placeholder="units…" onChange={e=>{setQty(e.target.value);setErrors(p=>({...p,qty:null}));}}
                  style={{...fld,flex:1,borderColor:errors.qty?"#ef4444":"#1e2d45"}}/>
                {toTarget>0&&<button onClick={()=>setQty(String(toTarget))} style={{background:"#0d1e36",border:"1px solid #2563eb44",color:"#60a5fa",borderRadius:6,padding:"8px 12px",fontSize:11,fontWeight:700,cursor:"pointer",whiteSpace:"nowrap"}}>↑ {toTarget.toLocaleString()}</button>}
              </div>
              {errors.qty&&<div style={{fontSize:10,color:"#ef4444",marginTop:2}}>{errors.qty}</div>}
            </div>

            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
              <div>
                <label style={lbl}>Production Start</label>
                <input type="date" value={packDate} onChange={e=>setPackDate(e.target.value)} style={fld}/>
              </div>
              <div>
                <label style={lbl}>Status</label>
                <select value={status} onChange={e=>setStatus(e.target.value)} style={fld}>
                  <option value="Planned">Planned</option><option value="Released">Released</option><option value="In Transit">In Transit</option>
                </select>
              </div>
            </div>

            {pd>0&&rcptDate&&(
              <div style={{background:"#080e1c",border:"1px solid #1a2740",borderRadius:6,padding:"9px 12px",display:"flex",flexWrap:"wrap",gap:12}}>
                <div style={{flex:1}}>
                  <div style={lbl}>Production</div>
                  <div style={{fontSize:12,color:"#e2e8f0",fontFamily:"'Courier New',monospace"}}>{fmtDate(packDate)} → {fmtDate(finishDate)} <span style={{color:"#4a6080"}}>({pd}d)</span></div>
                </div>
                <div style={{flex:1}}>
                  <div style={lbl}>Receipt in Country</div>
                  <div style={{fontSize:12,color:"#22c55e",fontWeight:700,fontFamily:"'Courier New',monospace"}}>{fmtDate(rcptDate)} <span style={{color:"#4a6080"}}>({TRANSIT_DAYS+1}d transit)</span></div>
                </div>
              </div>
            )}

            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
              <div>
                <label style={lbl}>Expedite</label>
                <select value={expedite} onChange={e=>setExpedite(e.target.value)} style={fld}>
                  <option value="Yes">Yes</option><option value="No">No</option>
                </select>
              </div>
              <div>
                <label style={lbl}>Planner</label>
                <input value={planner} onChange={e=>setPlanner(e.target.value)} style={fld}/>
              </div>
            </div>

            <div>
              <label style={lbl}>Notes</label>
              <textarea value={notes} onChange={e=>setNotes(e.target.value)} rows={2}
                style={{...fld,resize:"vertical",lineHeight:1.6,fontFamily:"sans-serif",fontSize:12}}/>
            </div>
          </div>

          {/* Impact panel */}
          <div style={{flex:"0 0 200px",padding:"22px 18px 22px 0",display:"flex",flexDirection:"column",gap:12}}>
            <div style={{fontSize:10,color:"#4a6080",fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",fontFamily:"sans-serif"}}>Impact Preview</div>
            {base&&qn>0?(
              <>
                <div style={{background:"#080e1c",border:"1px solid #1a2740",borderRadius:7,padding:"12px 14px",display:"flex",flexDirection:"column",gap:10}}>
                  <div>
                    <div style={{fontSize:9,color:"#4a6080",textTransform:"uppercase",letterSpacing:"0.08em",marginBottom:4,fontFamily:"sans-serif"}}>Current</div>
                    <div style={{fontSize:20,fontWeight:800,color:"#94a3b8",fontFamily:"'Courier New',monospace",marginBottom:6}}>{base.onHand.toLocaleString()}</div>
                    <StockBar value={base.onHand} target={base.target} warning={base.warning} critical={base.critical} width={172}/>
                  </div>
                  <div style={{borderTop:"1px solid #1e2d45",paddingTop:10}}>
                    <div style={{fontSize:9,color:"#4a6080",textTransform:"uppercase",letterSpacing:"0.08em",marginBottom:4,fontFamily:"sans-serif"}}>After Receipt</div>
                    <div style={{fontSize:20,fontWeight:800,color:SC[afterSt]?.text||"#e2e8f0",fontFamily:"'Courier New',monospace",marginBottom:6}}>{projOH.toLocaleString()}</div>
                    <StockBar value={projOH} target={base.target} warning={base.warning} critical={base.critical} width={172}/>
                  </div>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",paddingTop:4}}>
                    <StatusBadge status={calcStatus(base.onHand,base)} small/>
                    <span style={{color:"#334155"}}>→</span>
                    <StatusBadge status={afterSt} small/>
                  </div>
                </div>
                {pd>0&&(
                  <div style={{background:"#080e1c",border:"1px solid #1a2740",borderRadius:7,padding:"10px 12px",fontSize:10,color:"#64748b",fontFamily:"sans-serif",lineHeight:1.8}}>
                    <div>⏱ Prod: <b style={{color:"#38bdf8"}}>{pd} day{pd>1?"s":""}</b></div>
                    <div>🚚 Transit: <b style={{color:"#a78bfa"}}>{TRANSIT_DAYS+1} days</b></div>
                    <div>📦 Total: <b style={{color:"#22c55e"}}>{pd+TRANSIT_DAYS+1} days</b></div>
                  </div>
                )}
                {projOH>=base.target&&projOH<=base.target*1.35&&(
                  <div style={{background:"#0d2b1a",border:"1px solid #22c55e33",borderRadius:6,padding:"8px 10px",fontSize:10,color:"#22c55e",fontFamily:"sans-serif"}}>✓ Will restore healthy stock.</div>
                )}
                {projOH>base.target*1.35&&(
                  <div style={{background:"#181408",border:"1px solid #eab30840",borderRadius:6,padding:"8px 10px",fontSize:10,color:"#eab308",fontFamily:"sans-serif"}}>⚠ May cause overstock.</div>
                )}
              </>
            ):(
              <div style={{background:"#080e1c",border:"1px dashed #1a2740",borderRadius:7,padding:28,textAlign:"center",color:"#1e2d45"}}>
                <div style={{fontSize:28,marginBottom:8}}>📊</div>
                <div style={{fontSize:10,fontFamily:"sans-serif"}}>Select country, treatment & qty</div>
              </div>
            )}
          </div>
        </div>

        <div style={{padding:"12px 22px",borderTop:"1px solid #1a2740",display:"flex",justifyContent:"flex-end",gap:10,background:"#080e1c",borderRadius:"0 0 12px 12px"}}>
          <button onClick={onClose} style={{background:"#1e293b",border:"1px solid #334155",color:"#94a3b8",padding:"8px 20px",borderRadius:6,fontSize:13,fontWeight:600,cursor:"pointer"}}>Cancel</button>
          <button onClick={submit} style={{background:done?"#0d2b1a":"linear-gradient(135deg,#1d4ed8,#4f46e5)",border:"none",color:done?"#22c55e":"#fff",padding:"8px 26px",borderRadius:6,fontSize:13,fontWeight:700,cursor:"pointer",boxShadow:done?"none":"0 4px 14px rgba(79,70,229,0.45)"}}>
            {done?"✓ Created!":"Create Order →"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── ORDERS TABLE ─────────────────────────────────────────────────────────────
function OrdersView({orders, onCreateOrder, onMoveOrder}) {
  const [search,setSearch]=useState("");
  const [cF,setCF]=useState("ALL");
  const [sF,setSF]=useState("ALL");
  const [selected,setSelected]=useState(null);

  const rows=orders.filter(o=>{
    if(cF!=="ALL"&&o.country!==cF)return false;
    if(sF!=="ALL"&&o.status !==sF) return false;
    if(search&&!o.id.toLowerCase().includes(search.toLowerCase())&&!o.sku.toLowerCase().includes(search.toLowerCase()))return false;
    return true;
  });

  const td={padding:"7px 10px",fontSize:11,color:"#e2e8f0",borderBottom:"1px solid #080e1c",whiteSpace:"nowrap"};
  const hd={textAlign:"left",fontSize:9,color:"#4a6080",fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",padding:"7px 10px",background:"#060c18"};

  return (
    <div style={{display:"flex",gap:16}}>
      <div style={{flex:1,display:"flex",flexDirection:"column",gap:12,minWidth:0}}>
        <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"center"}}>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search…"
            style={{background:"#0b1221",border:"1px solid #1a2740",color:"#e2e8f0",borderRadius:6,padding:"6px 12px",fontSize:12,flex:"1 1 150px",outline:"none"}}/>
          {[
            {val:cF,set:setCF,opts:[["ALL","All Countries"],...Object.entries(COUNTRIES)]},
            {val:sF,set:setSF,opts:[["ALL","All Status"],["In Transit","In Transit"],["Released","Released"],["Planned","Planned"],["Delayed","Delayed"],["On Hold","On Hold"]]},
          ].map((f,i)=>(
            <select key={i} value={f.val} onChange={e=>f.set(e.target.value)}
              style={{background:"#0b1221",border:"1px solid #1a2740",color:"#94a3b8",borderRadius:6,padding:"6px 10px",fontSize:12,outline:"none"}}>
              {f.opts.map(([v,l])=><option key={v} value={v}>{l}</option>)}
            </select>
          ))}
          <button onClick={()=>onCreateOrder(null)} style={{background:"linear-gradient(135deg,#1d4ed8,#4f46e5)",border:"none",color:"#fff",padding:"7px 16px",borderRadius:6,fontSize:12,fontWeight:700,cursor:"pointer",marginLeft:"auto"}}>+ New Order</button>
        </div>
        <div style={{overflowX:"auto",borderRadius:8,border:"1px solid #1a2740"}}>
          <table style={{width:"100%",borderCollapse:"collapse"}}>
            <thead><tr>{["Order","PO","Ctry","SKU","Qty","Pack Start","Prod Days","Receipt","Status","Source"].map(h=><th key={h} style={hd}>{h}</th>)}</tr></thead>
            <tbody>
              {rows.map((o,ri)=>(
                <tr key={o.id+ri} onClick={()=>setSelected(selected?.id===o.id?null:o)}
                  style={{background:selected?.id===o.id?"#0d1e36":o.userCreated?"#05120a":ri%2===0?"#0b1221":"#080e1c",cursor:"pointer"}}>
                  <td style={{...td,fontFamily:"'Courier New',monospace",color:o.userCreated?"#4ade80":"#38bdf8",fontWeight:700}}>{o.id}</td>
                  <td style={{...td,fontSize:10,color:"#334155"}}>{o.po}</td>
                  <td style={td}><span style={{background:"#1a2740",borderRadius:3,padding:"1px 6px",fontSize:10,fontWeight:700,color:"#64748b"}}>{o.country}</span></td>
                  <td style={{...td,fontSize:10,color:TREAT_COLOR[o.treatment]||"#a78bfa",fontFamily:"'Courier New',monospace"}}>{o.sku}</td>
                  <td style={{...td,textAlign:"right",fontWeight:700,fontFamily:"'Courier New',monospace"}}>{o.qty.toLocaleString()}</td>
                  <td style={{...td,color:"#64748b",fontSize:10}}>{fmtDate(o.packDate)}</td>
                  <td style={{...td,textAlign:"center",color:"#a78bfa"}}>{prodDays(o.qty)}d</td>
                  <td style={{...td,fontSize:10}}>{fmtDate(receiptDate(o))}</td>
                  <td style={td}><OrderBadge status={o.status}/></td>
                  <td style={td}>{o.userCreated?<span style={{background:"#052010",color:"#4ade80",border:"1px solid #4ade8030",borderRadius:3,fontSize:9,fontWeight:700,padding:"2px 5px"}}>PLANNER</span>:<span style={{color:"#1e2d45",fontSize:10}}>ERP</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {selected&&(
        <div style={{width:240,flexShrink:0,background:"#0b1221",border:`1px solid ${selected.userCreated?"#4ade8030":"#1a2740"}`,borderRadius:8,padding:16,alignSelf:"flex-start"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
            <span style={{fontSize:12,fontWeight:800,color:selected.userCreated?"#4ade80":"#38bdf8",fontFamily:"'Courier New',monospace"}}>{selected.id}</span>
            <button onClick={()=>setSelected(null)} style={{background:"none",border:"none",color:"#4a6080",cursor:"pointer",fontSize:15}}>×</button>
          </div>
          {[["Country",`${selected.country} — ${COUNTRIES[selected.country]}`],["Treatment",selected.treatment],["SKU",selected.sku],["Quantity",selected.qty.toLocaleString()+" units"],["Pack Start",fmtDate(selected.packDate)],["Prod Days",prodDays(selected.qty)+"d"],["Pack Finish",fmtDate(addDays(selected.packDate,prodDays(selected.qty)-1))],["Receipt",fmtDate(receiptDate(selected))],["Expedite",selected.expedite],["Planner",selected.planner]].map(([k,v])=>(
            <div key={k} style={{marginBottom:9}}>
              <div style={{fontSize:9,color:"#4a6080",fontWeight:700,letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:2,fontFamily:"sans-serif"}}>{k}</div>
              <div style={{fontSize:11,color:"#e2e8f0",fontFamily:"sans-serif"}}>{v}</div>
            </div>
          ))}
          <div style={{marginBottom:9}}><div style={{fontSize:9,color:"#4a6080",fontWeight:700,textTransform:"uppercase",marginBottom:4,fontFamily:"sans-serif"}}>Status</div><OrderBadge status={selected.status}/></div>
          {selected.notes&&<div style={{background:"#1a2740",borderRadius:5,padding:"9px 10px",fontSize:10,color:"#64748b",lineHeight:1.6,fontFamily:"sans-serif"}}>📋 {selected.notes}</div>}
        </div>
      )}
    </div>
  );
}

// ─── APP ─────────────────────────────────────────────────────────────────────
const TABS = [
  {id:"dashboard",  label:"Dashboard",   icon:"◈"},
  {id:"planning",   label:"Planning",    icon:"▦"},
  {id:"projection", label:"Projection",  icon:"∿"},
  {id:"orders",     label:"Orders",      icon:"⊞"},
  {id:"leadtime",   label:"Lead Time",   icon:"⏱"},
];

export default function App() {
  const [tab,      setTab]      = useState("dashboard");
  const [orders,   setOrders]   = useState(INITIAL_ORDERS);
  const [modal,    setModal]    = useState(false);
  const [prefill,  setPrefill]  = useState(null);
  const [toast,    setToast]    = useState(null);
  const [ganttSel, setGanttSel] = useState(null);

  // Live inventory (user orders add to on-hand at receipt date, simplified as immediate for dashboard)
  const inventory = useMemo(()=>{
    return BASE_INV.map(base=>{
      const extra = orders.filter(o=>o.sku===base.sku&&o.userCreated&&o.status!=="On Hold").reduce((s,o)=>s+o.qty,0);
      const oh = base.onHand + extra;
      return {...base, onHand:oh, daysCover:Math.round(oh/base.avgDemand), status:calcStatus(oh,base)};
    });
  },[orders]);

  function openModal(pf) { setPrefill(pf||null); setModal(true); }

  function handleSubmit(order) {
    setOrders(prev=>[order,...prev]);
    setToast(`✓ ${order.id} created — ${order.sku} · ${order.qty.toLocaleString()} units · Receipt: ${fmtDate(receiptDate(order))}`);
    setTimeout(()=>setToast(null),5000);
  }

  function handleMoveOrder(orderId, newPackDate) {
    setOrders(prev=>prev.map(o=>{
      if(o.id!==orderId) return o;
      return {...o, packDate:newPackDate};
    }));
    setToast(`↔ ${orderId} rescheduled to start ${fmtDate(newPackDate)}`);
    setTimeout(()=>setToast(null),4000);
  }

  const newCount = orders.filter(o=>o.userCreated).length;

  return (
    <div style={{minHeight:"100vh",background:"#060c18",color:"#e2e8f0",fontFamily:"'IBM Plex Mono','Courier New',monospace"}}>
      {toast&&(
        <div style={{position:"fixed",bottom:24,right:24,zIndex:300,background:"#052010",border:"1px solid #4ade8040",borderRadius:8,padding:"12px 18px",fontSize:12,color:"#4ade80",fontWeight:700,boxShadow:"0 8px 32px rgba(0,0,0,0.5)",maxWidth:420,lineHeight:1.5,fontFamily:"sans-serif"}}>
          {toast}
        </div>
      )}

      {/* Header */}
      <div style={{background:"#080e1c",borderBottom:"1px solid #1a2740",padding:"0 20px",display:"flex",alignItems:"center",gap:12,position:"sticky",top:0,zIndex:10}}>
        <div style={{padding:"12px 0",display:"flex",alignItems:"center",gap:9}}>
          <div style={{width:26,height:26,background:"linear-gradient(135deg,#1d4ed8,#7c3aed)",borderRadius:5,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13}}>⬡</div>
          <div>
            <div style={{fontSize:12,fontWeight:800,color:"#f1f5f9"}}>VMI Control Tower</div>
            <div style={{fontSize:8,color:"#334155",fontWeight:600,letterSpacing:"0.12em",textTransform:"uppercase",fontFamily:"sans-serif"}}>Insulin Supply Chain · Line Cap: {LINE_CAPACITY.toLocaleString()} u/day</div>
          </div>
        </div>
        <div style={{display:"flex",gap:0,marginLeft:12}}>
          {TABS.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)}
              style={{background:tab===t.id?"#0b1221":"none",border:"none",color:tab===t.id?"#e2e8f0":"#4a6080",padding:"12px 14px",fontSize:11,fontWeight:tab===t.id?700:500,cursor:"pointer",borderBottom:tab===t.id?"2px solid #3b82f6":"2px solid transparent",display:"flex",alignItems:"center",gap:6,fontFamily:"inherit"}}>
              <span style={{opacity:0.7}}>{t.icon}</span>{t.label}
              {t.id==="orders"&&newCount>0&&<span style={{background:"#22c55e",color:"#000",borderRadius:10,fontSize:8,fontWeight:800,padding:"1px 5px"}}>{newCount}</span>}
            </button>
          ))}
        </div>
        <div style={{marginLeft:"auto",display:"flex",alignItems:"center",gap:12}}>
          <button onClick={()=>openModal(null)} style={{background:"linear-gradient(135deg,#1d4ed8,#4f46e5)",border:"none",color:"#fff",padding:"7px 18px",borderRadius:6,fontSize:11,fontWeight:700,cursor:"pointer",boxShadow:"0 4px 14px rgba(79,70,229,0.45)",fontFamily:"inherit"}}>+ Create Order</button>
          <div style={{fontSize:9,color:"#334155",textAlign:"right",fontFamily:"sans-serif"}}>
            <div style={{fontWeight:700,color:"#4a6080"}}>SNAPSHOT</div>
            <div style={{color:"#64748b"}}>2026-03-12</div>
          </div>
          <div style={{width:7,height:7,borderRadius:"50%",background:"#22c55e",boxShadow:"0 0 8px #22c55e"}}/>
        </div>
      </div>

      {/* Content */}
      <div style={{padding:20}}>
        {tab==="dashboard"  && <Dashboard inventory={inventory} orders={orders} onCreateOrder={openModal}/>}
        {tab==="orders"     && <OrdersView orders={orders} onCreateOrder={openModal} onMoveOrder={handleMoveOrder}/>}
        {tab==="projection" && <ProjectionView orders={orders} baseInv={BASE_INV}/>}
        {tab==="leadtime"   && <LeadTimeView orders={orders}/>}
        {tab==="planning"   && (
          <div style={{display:"flex",flexDirection:"column",gap:20}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
              <div>
                <div style={{fontSize:14,fontWeight:800,color:"#e2e8f0",marginBottom:3}}>Production Planning Board</div>
                <div style={{fontSize:11,color:"#4a6080",fontFamily:"sans-serif"}}>Drag bars to reschedule · Projection tab updates automatically · Capacity: {LINE_CAPACITY.toLocaleString()} units/day</div>
              </div>
              <button onClick={()=>openModal(null)} style={{background:"linear-gradient(135deg,#1d4ed8,#4f46e5)",border:"none",color:"#fff",padding:"7px 18px",borderRadius:6,fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>+ Add Order to Plan</button>
            </div>

            <GanttBoard
              orders={orders}
              onMoveOrder={handleMoveOrder}
              onSelectOrder={setGanttSel}
              selectedId={ganttSel}
              inventory={inventory}
            />

            {/* If an order is selected in Gantt, show its stock projection inline */}
            {ganttSel && (()=>{
              const sel = orders.find(o=>o.id===ganttSel);
              if(!sel) return null;
              const base = BASE_INV.find(b=>b.sku===sel.sku);
              if(!base) return null;
              const rows = buildProjection(base, orders);
              return (
                <div style={{background:"#080e1c",border:"1px solid #1a2740",borderRadius:10,padding:18}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
                    <div>
                      <span style={{fontSize:12,fontWeight:800,color:TREAT_COLOR[sel.treatment]||"#38bdf8",fontFamily:"'Courier New',monospace"}}>{sel.id}</span>
                      <span style={{fontSize:11,color:"#4a6080",marginLeft:10,fontFamily:"sans-serif"}}>{sel.sku} · {sel.qty.toLocaleString()} units · Receipt {fmtDate(receiptDate(sel))}</span>
                    </div>
                    <StatusBadge status={calcStatus(base.onHand,base)} small/>
                  </div>
                  <ProjectionChart rows={rows} base={base} width={Math.max(500,PLAN_DAYS*22)} height={80}/>
                  <div style={{fontSize:10,color:"#334155",marginTop:6,fontFamily:"sans-serif"}}>
                    Stock projection for <b style={{color:"#38bdf8"}}>{base.sku}</b> — move the order bar above to see this chart update in real time
                  </div>
                </div>
              );
            })()}
          </div>
        )}
      </div>

      {modal&&<CreateOrderModal onClose={()=>setModal(false)} onSubmit={handleSubmit} orders={orders} inventory={inventory} prefill={prefill}/>}
    </div>
  );
}
